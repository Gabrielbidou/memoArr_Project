/*************************************************************
Names: Gabriel Brunet
	   Jean Fei
*************************************************************/

#pragma once
#include <string>
#include "Reward.h"

using namespace std;

//D�finitions
typedef enum { Top, Bottom, Left, Right } Side;

class Player {
private:
	bool endOfGame;
	bool active;
	Side side;
	const string name;
	int numRubis;

	string sides[4] = { "Top", "Bottom", "Left", "Right" };
public:
	Player(){}
	Player(string name) : name(name), numRubis(0) {}

	//Overload de l'op�rateur <<
	friend ostream& operator<<(ostream& os, Player& player)
	{
		player.print();
		return os;
	}

	string getName() const { return name; }
	bool isActive() const { return active; }
	int getNRubis() { return numRubis; }
	Side getSide() const { return side; }
	void setSide(Side side) { this->side = side; }
	void setActive(bool flag) { this->active = flag; }
	void addReward(const Reward &reward);
	void setDisplayMode(bool endOfGame);

private:
	void print();
};